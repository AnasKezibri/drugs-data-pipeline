"""drugs_publiction_graph
"""

__version__ = "0.1"
